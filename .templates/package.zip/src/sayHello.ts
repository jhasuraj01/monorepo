export const sayHello = (name: string): string => {
  return `Hello ${name}!!!`
}
