# organization-cli-app

Note: Make sure you have already run `pnpm setup` or have set `PNPM_HOME` env variable.

Run the CLI using below command

```sh
pnpm exec organization-cli-app
```

Delete exec command

```sh
rm $PNPM_HOME/organization-cli-app
```
